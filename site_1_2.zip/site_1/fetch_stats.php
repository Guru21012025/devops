<?php
require_once 'setup_database.php';

$conn = getDatabaseConnection();
$conn->select_db("hr_system");

function fetchStatistics($conn, $query) {
    $result = $conn->query($query);
    if ($result && $row = $result->fetch_assoc()) {
        return $row['count'];
    }
    return 0; // Return 0 if the query fails or no rows are returned
}

$stats = [
    'projects' => fetchStatistics($conn, "SELECT COUNT(*) AS count FROM projects"),
    'clients' => fetchStatistics($conn, "SELECT COUNT(*) AS count FROM clients"),
    'tasks' => fetchStatistics($conn, "SELECT COUNT(*) AS count FROM tasks"),
    'employees' => fetchStatistics($conn, "SELECT COUNT(*) AS count FROM employees")
];

echo json_encode($stats);
$conn->close();
?>
