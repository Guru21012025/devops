<?php
require_once 'config.php'; // Ensure config.php is included only once
// Create connection
$conn = getDatabaseConnection();

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS hr_system";
if ($conn->query($sql) === TRUE) {
    //echo "Database created successfully<br>";
} else {
    die("Error creating database: " . $conn->error);
}

// Select the database
$conn->select_db("hr_system");

/*
 * Required tables for the application:
 * 1. activities: Stores activity logs.
 * 2. applied_jobs: Stores records of jobs applied by employees.
 * 3. attendance: Stores attendance records for employees.
 * 4. provident_fund: Stores provident fund details for employees.
 * 5. questions: Stores questions for interviews or assessments.
 * 6. assets: Stores company asset details.
 * 7. projects: Stores project details.
 * 8. clients: Stores client details.
 * 9. tasks: Stores task details.
 * 10. employees: Stores employee details.
 * 11. invoices: Stores invoice details.
 * 12. estimates: Stores estimate details.
 * 13. tickets: Stores support ticket details.
 * 14. training: Stores training details.
 * 15. performance: Stores performance review details.
 * 16. payroll: Stores payroll details.
 * 17. notifications: Stores notification settings.
 * 18. roles_permissions: Stores roles and permissions for users.
 * 19. jobs: Stores job details.
 * 20. leaves: Stores leave details.
 */

$tables = [
    "activities" => "CREATE TABLE IF NOT EXISTS activities (
        id INT AUTO_INCREMENT PRIMARY KEY,
        activity_name VARCHAR(255) NOT NULL,
        description TEXT,
        activity_date DATE NOT NULL, -- Ensure 'activity_date' column exists
        date DATE NOT NULL
    )",
    "users" => "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL
    )",
    "jobs" => "CREATE TABLE IF NOT EXISTS jobs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        department VARCHAR(100),
        job_type ENUM('Full Time', 'Part Time', 'Internship') NOT NULL
    )",
    "employees" => "CREATE TABLE IF NOT EXISTS employees (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        phone VARCHAR(20),
        position VARCHAR(100),
        department VARCHAR(100)
    )",
    "attendance" => "CREATE TABLE IF NOT EXISTS attendance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        date DATE NOT NULL,
        status ENUM('Present', 'Absent', 'Leave') NOT NULL,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "applied_jobs" => "CREATE TABLE IF NOT EXISTS applied_jobs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        job_id INT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
    )",
    "provident_fund" => "CREATE TABLE IF NOT EXISTS provident_fund (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        contribution_amount DECIMAL(10, 2) NOT NULL,
        contribution_date DATE NOT NULL,
        FOREIGN KEY (employee_id) REFERENCES employees(id)
    )",
    "provident_funds" => "CREATE TABLE IF NOT EXISTS provident_funds (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        contribution_amount DECIMAL(10, 2) NOT NULL,
        contribution_date DATE NOT NULL,
        description TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "questions" => "CREATE TABLE IF NOT EXISTS questions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        question_text TEXT NOT NULL,
        category VARCHAR(100),
        difficulty_level VARCHAR(50)
    )",

    "assets" => "CREATE TABLE IF NOT EXISTS assets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        asset_name VARCHAR(255) NOT NULL, -- Ensure 'asset_name' column exists
        category VARCHAR(255), -- Add 'category' column
        description TEXT,
        purchase_date DATE,
        status ENUM('Available', 'Assigned', 'Under Maintenance') NOT NULL
    )",
    "projects" => "CREATE TABLE IF NOT EXISTS projects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        start_date DATE,
        end_date DATE,
        status VARCHAR(50)
    )",
    "clients" => "CREATE TABLE IF NOT EXISTS clients (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL, -- Ensure 'email' column exists
        phone VARCHAR(20),
        address TEXT
    )",
    "tasks" => "CREATE TABLE IF NOT EXISTS tasks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        assigned_to INT,
        due_date DATE,
        status VARCHAR(50),
        FOREIGN KEY (project_id) REFERENCES projects(id),
        FOREIGN KEY (assigned_to) REFERENCES employees(id)
    )",
    "invoices" => "CREATE TABLE IF NOT EXISTS invoices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        client_id INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        due_date DATE NOT NULL,
        status ENUM('Paid', 'Unpaid', 'Partially Paid') NOT NULL,
        FOREIGN KEY (client_id) REFERENCES clients(id)
    )",
    "estimates" => "CREATE TABLE IF NOT EXISTS estimates (
        id INT AUTO_INCREMENT PRIMARY KEY,
        client_id INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        created_date DATE NOT NULL,
        status ENUM('Approved', 'Pending', 'Rejected') NOT NULL,
        FOREIGN KEY (client_id) REFERENCES clients(id)
    )",
    "tickets" => "CREATE TABLE IF NOT EXISTS tickets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        subject VARCHAR(255) NOT NULL,
        description TEXT,
        status ENUM('Open', 'Closed', 'In Progress') NOT NULL
    )",
    "training" => "CREATE TABLE IF NOT EXISTS training (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        start_date DATE,
        end_date DATE,
        status ENUM('Scheduled', 'Completed', 'Cancelled') NOT NULL
    )",
    "performance" => "CREATE TABLE IF NOT EXISTS performance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        review_date DATE NOT NULL,
        score INT NOT NULL,
        feedback TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id)
    )",
    "payroll" => "CREATE TABLE IF NOT EXISTS payroll (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        salary DECIMAL(10, 2) NOT NULL,
        payment_date DATE NOT NULL,
        FOREIGN KEY (employee_id) REFERENCES employees(id)
    )",
    "notifications" => "CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        type VARCHAR(100) NOT NULL,
        message TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES employees(id)
    )",
    "roles_permissions" => "CREATE TABLE IF NOT EXISTS roles_permissions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        role_name VARCHAR(100) NOT NULL,
        permissions TEXT NOT NULL
    )",
    "register" => "CREATE TABLE IF NOT EXISTS register (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "leaves" => "CREATE TABLE IF NOT EXISTS leaves (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee VARCHAR(255) NOT NULL,
        designation VARCHAR(255) NOT NULL,
        leave_type VARCHAR(255) NOT NULL,
        from_date DATE NOT NULL,
        to_date DATE NOT NULL,
        no_of_days INT NOT NULL,
        reason TEXT NOT NULL,
        status VARCHAR(50) NOT NULL DEFAULT 'Pending'
    )",
    "holidays" => "CREATE TABLE IF NOT EXISTS holidays (
        id INT AUTO_INCREMENT PRIMARY KEY,
        holiday_name VARCHAR(255) NOT NULL,
        holiday_date DATE NOT NULL,
        description TEXT
    )",
    "employee_leaves" => "CREATE TABLE IF NOT EXISTS employee_leaves (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        leave_type VARCHAR(255) NOT NULL,
        from_date DATE NOT NULL,
        to_date DATE NOT NULL,
        no_of_days INT NOT NULL,
        reason TEXT NOT NULL,
        status VARCHAR(50) NOT NULL DEFAULT 'Pending',
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "departments" => "CREATE TABLE IF NOT EXISTS departments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT
    )",
    "designations" => "CREATE TABLE IF NOT EXISTS designations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT
    )",
    "timesheets" => "CREATE TABLE IF NOT EXISTS timesheets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        date DATE NOT NULL,
        hours_worked DECIMAL(5, 2) NOT NULL,
        task_description TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "shift_scheduling" => "CREATE TABLE IF NOT EXISTS shift_scheduling (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        shift_name VARCHAR(255) NOT NULL,
        start_time TIME NOT NULL,
        end_time TIME NOT NULL,
        shift_date DATE NOT NULL,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "overtime" => "CREATE TABLE IF NOT EXISTS overtime (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        date DATE NOT NULL,
        hours DECIMAL(5, 2) NOT NULL,
        reason TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "leads" => "CREATE TABLE IF NOT EXISTS leads (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(20),
        company VARCHAR(255),
        status ENUM('New', 'Contacted', 'Qualified', 'Lost') NOT NULL DEFAULT 'New',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "payments" => "CREATE TABLE IF NOT EXISTS payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        payment_date DATE NOT NULL,
        payment_method VARCHAR(50),
        description TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "expenses" => "CREATE TABLE IF NOT EXISTS expenses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        expense_date DATE NOT NULL,
        category VARCHAR(255),
        description TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "taxes" => "CREATE TABLE IF NOT EXISTS taxes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tax_name VARCHAR(255) NOT NULL,
        tax_rate DECIMAL(5, 2) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "categories" => "CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "budgets" => "CREATE TABLE IF NOT EXISTS budgets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        total_amount DECIMAL(10, 2) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "budget_expenses" => "CREATE TABLE IF NOT EXISTS budget_expenses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        category_id INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        expense_date DATE NOT NULL,
        description TEXT,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
    )",
    "budget_revenues" => "CREATE TABLE IF NOT EXISTS budget_revenues (
        id INT AUTO_INCREMENT PRIMARY KEY,
        source VARCHAR(255) NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        revenue_date DATE NOT NULL,
        description TEXT
    )",
    "salaries" => "CREATE TABLE IF NOT EXISTS salaries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        basic_salary DECIMAL(10, 2) NOT NULL,
        allowances DECIMAL(10, 2),
        deductions DECIMAL(10, 2),
        net_salary DECIMAL(10, 2) NOT NULL,
        payment_date DATE NOT NULL,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "payroll_items" => "CREATE TABLE IF NOT EXISTS payroll_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        type ENUM('Allowance', 'Deduction') NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        description TEXT
    )",
    "expense_reports" => "CREATE TABLE IF NOT EXISTS expense_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_name VARCHAR(255) NOT NULL,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "invoice_reports" => "CREATE TABLE IF NOT EXISTS invoice_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_name VARCHAR(255) NOT NULL,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "project_reports" => "CREATE TABLE IF NOT EXISTS project_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_name VARCHAR(255) NOT NULL,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "payment_reports" => "CREATE TABLE IF NOT EXISTS payment_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_name VARCHAR(255) NOT NULL,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "task_reports" => "CREATE TABLE IF NOT EXISTS task_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_name VARCHAR(255) NOT NULL,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "user_reports" => "CREATE TABLE IF NOT EXISTS user_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_name VARCHAR(255) NOT NULL,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "employee_reports" => "CREATE TABLE IF NOT EXISTS employee_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_name VARCHAR(255) NOT NULL,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "payslip_reports" => "CREATE TABLE IF NOT EXISTS payslip_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_name VARCHAR(255) NOT NULL,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "leave_reports" => "CREATE TABLE IF NOT EXISTS leave_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_name VARCHAR(255) NOT NULL,
        generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "daily_reports" => "CREATE TABLE IF NOT EXISTS daily_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        report_name VARCHAR(255) NOT NULL,
        report_date DATE NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "performance_indicators" => "CREATE TABLE IF NOT EXISTS performance_indicators (
        id INT AUTO_INCREMENT PRIMARY KEY,
        indicator_name VARCHAR(255) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "performance_reviews" => "CREATE TABLE IF NOT EXISTS performance_reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        review_date DATE NOT NULL,
        score INT NOT NULL,
        feedback TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "performance_appraisals" => "CREATE TABLE IF NOT EXISTS performance_appraisals (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        appraisal_date DATE NOT NULL,
        appraisal_score INT NOT NULL,
        comments TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "goal_tracking" => "CREATE TABLE IF NOT EXISTS goal_tracking (
        id INT AUTO_INCREMENT PRIMARY KEY,
        goal_name VARCHAR(255) NOT NULL,
        description TEXT,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        status ENUM('In Progress', 'Completed', 'On Hold') NOT NULL
    )",
    "goal_types" => "CREATE TABLE IF NOT EXISTS goal_types (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type_name VARCHAR(255) NOT NULL,
        description TEXT
    )",
    "trainers" => "CREATE TABLE IF NOT EXISTS trainers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        expertise VARCHAR(255),
        contact_info TEXT
    )",
    "training_sessions" => "CREATE TABLE IF NOT EXISTS training_sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        session_name VARCHAR(255) NOT NULL,
        trainer_id INT NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        status ENUM('Scheduled', 'Completed', 'Cancelled') NOT NULL,
        FOREIGN KEY (trainer_id) REFERENCES trainers(id) ON DELETE CASCADE
    )",
    "training_types" => "CREATE TABLE IF NOT EXISTS training_types (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type_name VARCHAR(255) NOT NULL,
        description TEXT
    )",
    "promotions" => "CREATE TABLE IF NOT EXISTS promotions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        promotion_date DATE NOT NULL,
        new_position VARCHAR(255) NOT NULL,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "resignations" => "CREATE TABLE IF NOT EXISTS resignations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        resignation_date DATE NOT NULL,
        reason TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "terminations" => "CREATE TABLE IF NOT EXISTS terminations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        termination_date DATE NOT NULL,
        reason TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "candidates" => "CREATE TABLE IF NOT EXISTS candidates (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        phone VARCHAR(20),
        applied_position VARCHAR(255), -- Ensure 'applied_position' column exists
        resume_file VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "resumes" => "CREATE TABLE IF NOT EXISTS resumes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        candidate_id INT NOT NULL,
        resume_file VARCHAR(255) NOT NULL,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE
    )",
    "shortlisted_candidates" => "CREATE TABLE IF NOT EXISTS shortlisted_candidates (
        id INT AUTO_INCREMENT PRIMARY KEY,
        candidate_id INT NOT NULL,
        job_id INT NOT NULL,
        FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
        FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
    )",
    "interview_questions" => "CREATE TABLE IF NOT EXISTS interview_questions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        question_text TEXT NOT NULL,
        category VARCHAR(255),
        difficulty_level ENUM('Easy', 'Medium', 'Hard') NOT NULL
    )",
    "offer_approvals" => "CREATE TABLE IF NOT EXISTS offer_approvals (
        id INT AUTO_INCREMENT PRIMARY KEY,
        candidate_id INT NOT NULL,
        job_id INT NOT NULL,
        approval_status ENUM('Pending', 'Approved', 'Rejected') NOT NULL,
        FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
        FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
    )",
    "experience_levels" => "CREATE TABLE IF NOT EXISTS experience_levels (
        id INT AUTO_INCREMENT PRIMARY KEY,
        level_name VARCHAR(255) NOT NULL,
        description TEXT
    )",
    "schedule_timings" => "CREATE TABLE IF NOT EXISTS schedule_timings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        shift_start TIME NOT NULL,
        shift_end TIME NOT NULL,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "aptitude_results" => "CREATE TABLE IF NOT EXISTS aptitude_results (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        test_date DATE NOT NULL,
        result_date DATE NOT NULL, -- Ensure 'result_date' column exists
        score INT NOT NULL,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )",
    "email_settings" => "CREATE TABLE IF NOT EXISTS email_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        smtp_server VARCHAR(255) NOT NULL,
        smtp_port INT NOT NULL,
        username VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        encryption ENUM('None', 'SSL', 'TLS') NOT NULL
    )",
    "approval_settings" => "CREATE TABLE IF NOT EXISTS approval_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_name VARCHAR(255) NOT NULL,
        description TEXT
    )",
    "leave_types" => "CREATE TABLE IF NOT EXISTS leave_types (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type_name VARCHAR(255) NOT NULL,
        description TEXT
    )",
    "cron_settings" => "CREATE TABLE IF NOT EXISTS cron_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cron_name VARCHAR(255) NOT NULL,
        schedule VARCHAR(255) NOT NULL,
        status ENUM('Active', 'Inactive') NOT NULL
    )",
    "components" => "CREATE TABLE IF NOT EXISTS components (
        id INT AUTO_INCREMENT PRIMARY KEY,
        component_name VARCHAR(255) NOT NULL,
        description TEXT
    )",
    "subscriptions" => "CREATE TABLE IF NOT EXISTS subscriptions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        subscription_name VARCHAR(255) NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        duration INT NOT NULL COMMENT 'Duration in days'
    )",
    "company_subscriptions" => "CREATE TABLE IF NOT EXISTS company_subscriptions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        subscription_id INT NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        FOREIGN KEY (company_id) REFERENCES clients(id) ON DELETE CASCADE,
        FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE
    )",
    "subscribed_companies" => "CREATE TABLE IF NOT EXISTS subscribed_companies (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        subscription_id INT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES clients(id) ON DELETE CASCADE,
        FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE
    )"
];

foreach ($tables as $table => $query) {
    if ($conn->query($query) === TRUE) {
        // echo "Table '$table' created successfully<br>"; // Suppress this output
    } else {
        // echo "Error creating table '$table': " . $conn->error . "<br>"; // Suppress this output
    }
}

// Handle dynamic data operations (INSERT, UPDATE, DELETE) via POST
if (basename($_SERVER['PHP_SELF']) === 'setup_database.php') { // Only process POST if accessed directly
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $operation = $_POST['operation'] ?? null; // 'insert', 'update', or 'delete'
        $table = $_POST['table'] ?? null;
        $data = $_POST['data'] ?? null; // Associative array for insert/update
        $conditions = $_POST['conditions'] ?? null; // Conditions for update/delete

        if ($operation && $table && $data) {
            switch ($operation) {
                case 'insert':
                    // Prepare INSERT query
                    $columns = implode(", ", array_keys($data));
                    $values = implode(", ", array_map(function ($value) use ($conn) {
                        return "'" . $conn->real_escape_string($value) . "'";
                    }, array_values($data)));
                    $query = "INSERT INTO $table ($columns) VALUES ($values)";
                    break;

                case 'update':
                    // Prepare UPDATE query
                    if (!$conditions) {
                        echo "Conditions are required for update operations.<br>";
                        exit;
                    }
                    $setClause = implode(", ", array_map(function ($key, $value) use ($conn) {
                        return "$key = '" . $conn->real_escape_string($value) . "'";
                    }, array_keys($data), $data));
                    $query = "UPDATE $table SET $setClause WHERE $conditions";
                    break;

                case 'delete':
                    // Prepare DELETE query
                    if (!$conditions) {
                        echo "Conditions are required for delete operations.<br>";
                        exit;
                    }
                    $query = "DELETE FROM $table WHERE $conditions";
                    break;

                default:
                    echo "Invalid operation.<br>";
                    exit;
            }

            // Execute the query
            if ($conn->query($query) === TRUE) {
                echo ucfirst($operation) . " operation on '$table' completed successfully.<br>";
            } else {
                echo "Error during $operation operation on '$table': " . $conn->error . "<br>";
            }
        } else {
            echo "Invalid input. Operation, table, and data are required.<br>";
        }
    }
}

$conn->close();
?>
