<?php
require_once 'setup_database.php'; // Include the reusable database connection logic

$conn = getDatabaseConnection(); // Establish connection
$conn->select_db("hr_system"); // Select the database

// Fetch all provident fund records
$query = "SELECT pf.id, e.name AS employee_name, pf.contribution_amount, pf.contribution_date 
          FROM provident_fund pf
          JOIN employees e ON pf.employee_id = e.id";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Provident Fund</title>
</head>
<body>
    <h1>Provident Fund Records</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Employee Name</th>
                <th>Contribution Amount</th>
                <th>Contribution Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['employee_name']; ?></td>
                        <td><?php echo $row['contribution_amount']; ?></td>
                        <td><?php echo $row['contribution_date']; ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php
$conn->close();
?>
