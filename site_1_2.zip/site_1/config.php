<?php
$servername = "localhost";
$username = "root";
$password = "";

// Function to establish a database connection
function getDatabaseConnection() {
    global $servername, $username, $password;
    $conn = new mysqli($servername, $username, $password);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}

?>